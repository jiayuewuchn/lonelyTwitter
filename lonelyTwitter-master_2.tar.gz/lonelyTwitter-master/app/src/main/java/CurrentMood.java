
public abstract class CurrentMood {

}
